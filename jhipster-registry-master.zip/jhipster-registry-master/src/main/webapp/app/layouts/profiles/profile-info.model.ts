export class ProfileInfo {
    activeProfiles: string[];
    ribbonEnv: string;
    inProduction: boolean;
    swaggerEnabled: boolean;
    configurationSources: Array<any>;
}
