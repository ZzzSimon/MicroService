package io.github.jhipster.registry.config;

public class Constants {

    public static final String PROFILE_OAUTH2 = "oauth2";
    public static final String PROFILE_UAA = "uaa";

    private Constants() {
    }
}
