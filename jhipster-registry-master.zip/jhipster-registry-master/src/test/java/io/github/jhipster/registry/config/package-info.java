package io.github.jhipster.registry.config;
